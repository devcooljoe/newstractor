


<?php $__env->startSection('title'); ?>

<title>The News Reporter a Magazine Category Flat Bootstarp Responsive Website Template| Home :: w3layouts</title>
<meta name="keywords" content="The keywords" />
<meta name="description" content="The description">
<!--webfont-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="main-content">
	<div class="col-md-9 total-news">
		<?php if($live->count()>0): ?>
		<div class="live-market">
			<h3><span>live</span> market</h3>
			<?php $__currentLoopData = $live; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="bull">
				<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">
					<div class="pic-box" class="img-responsive">
						<img class="img-responsive" src="/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>">
					</div>
				</a>
			</div>
			<div class="bull-text">
				<a class="bull1" href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
				<p><?php echo e(strlen($post->body)>300?substr($post->body, 0, 300).'...':$post->body); ?></p>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="clearfix"></div>
		</div>
		<?php endif; ?>
		<div class="posts">
			<div class="left-posts">
				<div class="world-news">
					<?php if($world->count()>0): ?>
					<div class="main-title-head">
						<h3>from around the world</h3>
						<a href="#">More +</a>
						<div class="clearfix"></div>
					</div>
					<div class="world-news-grids ">
						<?php $__currentLoopData = $world; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="world-news-grid img-responsive">
							<div class="img-cont-post img-responsive">
								<img src="/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" class="img-responsive"/>
							</div>
							<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" class="title"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
							<p><?php echo e(strlen($post->body)>95?substr($post->body, 0, 95).'...':$post->body); ?></p>
							<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="clearfix"></div>
					</div>
					<?php endif; ?>
				</div>
				<div class="latest-articles">
					<?php if($latest->count()>0): ?>
					<div class="main-title-head">
						<h3>latest articles</h3>
						<a href="#">More +</a>
						<div class="clearfix"></div>
					</div>
					<div class="world-news-grids">
						<?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="world-news-grid img-responsive">
							<div class="img-cont-post img-responsive">
								<img src="/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" class="img-responsive"/>
							</div>
							<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" class="title"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
							<p><?php echo e(strlen($post->body)>95?substr($post->body, 0, 95).'...':$post->body); ?></p>
							<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="clearfix"></div>
					</div>
					<?php endif; ?>
				</div>
				<div class="gallery">
					<div class="main-title-head">
						<h3>gallery</h3>
						<a href="#">More +</a>
						<div class="clearfix"></div>
					</div>
					<div class="gallery-images">
						<?php if($galtop->count()>0): ?>
						<div class="course_demo1">
							<ul id="flexiselDemo1">
								<?php $__currentLoopData = $galtop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">
										<div class="img-cont-post img-responsive" style="height:120px;">
										<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" />
										</div>
									</a>
								</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
						<?php endif; ?>
						<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
						<script type="text/javascript">
							$(window).load(function () {
								$("#flexiselDemo1").flexisel({
									visibleItems: 3,
									animationSpeed: 1000,
									autoPlay: true,
									autoPlaySpeed: 3000,
									pauseOnHover: true,
									enableResponsiveBreakpoints: true,
									responsiveBreakpoints: {
										portrait: {
											changePoint: 480,
											visibleItems: 2
										},
										landscape: {
											changePoint: 640,
											visibleItems: 2
										},
										tablet: {
											changePoint: 768,
											visibleItems: 3
										}
									}
								});

							});
						</script>
						<script type="text/javascript" src="js/jquery.flexisel.js"></script>
					</div>
					<?php if($galbottom->count()>0): ?>
					<div class="course_demo1">
						<ul id="flexiselDemo">
							<?php $__currentLoopData = $galbottom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">
										<div class="img-cont-post img-responsive" style="height:120px;">
										<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" />
										</div>
									</a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<?php endif; ?>
					<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
					<script type="text/javascript">
						$(window).load(function () {
							$("#flexiselDemo").flexisel({
								visibleItems: 3,
								animationSpeed: 1000,
								autoPlay: true,
								autoPlaySpeed: 3000,
								pauseOnHover: true,
								enableResponsiveBreakpoints: true,
								responsiveBreakpoints: {
									portrait: {
										changePoint: 480,
										visibleItems: 2
									},
									landscape: {
										changePoint: 640,
										visibleItems: 2
									},
									tablet: {
										changePoint: 768,
										visibleItems: 3
									}
								}
							});

						});
					</script>
					<script type="text/javascript" src="js/jquery.flexisel.js"></script>

				</div>
				<div class="tech-news">
					<?php if($leftmore->count()>0): ?>
					<div class="main-title-head">
						<h3>More To Read</h3>
						<a href="#">More +</a>
						<div class="clearfix"></div>
					</div>
					<?php endif; ?>
					<div class="tech-news-grids">
						<div class="left-tech-news">
							<?php $__currentLoopData = $leftmore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tech-news-grid span_66">
								<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
								<p><?php echo e(strlen($post->body)>100?substr($post->body, 0, 100).'...':$post->body); ?>

								</p>
								<p>by <a href="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>" style="text-transform: capitalize;"><?php echo e($post->user->name); ?></a> | <?php echo e($post->comment->count()); ?>

								<?php echo e($post->comment->count()>1?'Comments':'Comment'); ?></p>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="right-tech-news">
							<?php $__currentLoopData = $rightmore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tech-news-grid span_66">
								<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
								<p><?php echo e(strlen($post->body)>100?substr($post->body, 0, 100).'...':$post->body); ?>

								</p>
								<p>by <a href="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>" style="text-transform: capitalize;"><?php echo e($post->user->name); ?></a> | <?php echo e($post->comment->count()); ?>

								<?php echo e($post->comment->count()>1?'Comments':'Comment'); ?></p>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="right-posts">
				<?php if($editorial->count()>0): ?>
				<div class="editorial">
					<h3>editorial</h3>
					<?php $__currentLoopData = $editorial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="editor">
						<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" class="img-cont-post">
							<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" />
						</a>
						<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>

	<div class="col-md-3 side-bar">
		<div class="videos">
			<?php $__currentLoopData = $maylike; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="video-grid">
				<div class="video" style="border: 2px solid white;overflow:hidden">
					<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" class="img-responsive">
				</div>
				<div class="video-name">
					<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">
						<?php echo e(substr($post->title, 0, 80)); ?>

						<?php echo e(strlen($post->title)>80?'...':''); ?>

					</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<a class="more1" href="#">More +</a>
			<div class="clearfix"></div>
		</div>
		<div class="sign_up text-center" id="subscribe">
			<h3>Sign Up for Newsletter</h3>
			<p class="sign">Sign up to receive our free newsletters!</p>
			<form>
				<input type="text" class="text" value="Name" onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'Name';}">
				<input type="text" class="text" value="Email Address" onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'Email Address';}">
				<input type="submit" value="submit">
			</form>
			<p class="spam">We do not spam. We value your privacy!</p>
		</div>
		<div class="clearfix"></div>
		<?php if($popular->count()>0): ?>
			<div class="popular mpopular">
				<div class="main-title-head">
					<h5>popular</h5>
					<h4> Most read</h4>
					<div class="clearfix"></div>
				</div>
				<div class="popular-news">
					<?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="popular-grid">
						<i>
							<?php echo e(((explode('-', $post->date))[0])); ?> <?php echo e(((explode('-', $post->date))[1])); ?>

							<?php echo e(((explode('-', $post->date))[2])); ?>, <?php echo e(((explode('-', $post->date))[3])); ?>

						</i>
						<p><?php echo e(substr($post->title, 0, 80)); ?>

							<?php echo e(strlen($post->title)>80?'...':''); ?>

							<a title="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a>
						</p>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>				
		<?php endif; ?>
		<div class="subscribe-now">
			<div class="discount">
				<a href="#subscribe">
					<div class="save">
						<p>Save</p>
						<p>upto</p>
					</div>
					<div class="percent">
						<h2>50%</h2>
					</div>
					<div class="clearfix"></div>
			</div>
			<h3 class="sn">subscribe now</h3>
			</a>
		</div>
		<div class="clearfix"></div>
	</div>
	<div class="clearfix"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\newstractor\resources\views/news\business.blade.php ENDPATH**/ ?>