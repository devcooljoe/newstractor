<?php $__env->startSection('title'); ?>
<title>Search Results For "<?php echo e($q); ?>"</title>
<link rel="stylesheet" type="text/css" href="/css/profile.css">
<meta name="keyword" content="newstractor, news, politics, breaking news, updates, trending" />
<meta name="description" content="Newstractor Keep you up with global news updates, trends, local news, etc.. We are building the best global community and will want you to be part.">
<meta property="og:locale" content="en_EN" />
<meta property="og:type" content="article" />
<meta property="og:title" content=" Newstractor - Global Breaking news updates, Latest news headlines" />
<meta property="og:description" content="Newstractor Keep you up with global news updates, trends, local news, etc.. We are building the best global community and will want you to be part." />
<meta property="og:url" content="<?php echo e(route('index')); ?>" />
<meta property="og:site_name" content="Newstractor" />
<meta property="og:image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="og:image:secure_url" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="og:image:width" content="800" />
<meta property="og:image:height" content="450" />
<meta property="og:image:alt" content="" />
<meta property="article:tag" content="about, news, headlines, Newstractor" />
<meta property="article:section" content="" />
<meta property="article:published_time" content="" />
<meta property="article:modified_time" content="" />
<meta property="article:author" content="" />
<meta name="twitter:card" content="summary" />
<meta property="twitter:title" content="Newstractor - Global Breaking news updates, Latest news headlines" />
<meta property="twitter:description" content="Newstractor Keep you up with global news updates, trends, local news, etc.. We are building the best global community and will want you to be part." />
<meta property="twitter:url" content="" />
<meta property="twitter:image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="twitter:image:width" content="800" />
<meta property="twitter:image:height" content="450" />
<meta property="twitter:image:alt" content="" />

<meta property="profile:username" content="" />
<link rel="image_src" href="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta itemprop="image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta name="msapplication-TileImage" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="profile">
	<div class="wrap">
        <br>
        <h3 class="search-result-head">
            Search Results For "<?php echo e($q); ?>"
        </h3>

        <div class="profile-main img-responsive" style="width:700px;box-shadow:none;">
            <?php if($count<=0): ?>
            <h4 class="search-result-head text-center">No Result Found!</h4>
            <?php endif; ?>
            <?php if($model == 'post'): ?>
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $result->body = \App\Custom::filterPost($result->body) ?>
                <div class="result-s">
                    <a href="<?php echo e(route('index')); ?>/<?php echo e($result->custom_id); ?>" class="search-head">
                        <h4><?php echo e(strlen($result->title)>95?substr($result->title, 0, 95).'...':$result->title); ?></h4>
                    </a>
                    <p class="search-parag"><?php echo e(strlen($result->body)>170?substr($result->body, 0, 170).'...':$result->body); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="result-s">
                    <a href="<?php echo e(route('index')); ?>/profile/<?php echo e($user->username ?? $user->id); ?>" class="search-head">
                        <h4><?php echo e($user->name); ?> - <?php echo e($user->profile->title); ?></h4>
                    </a>
                    <p class="search-parag"><?php echo e($user->profile->description); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
            
            <?php if($count>10): ?>
            <ul class="pagination pagination-sm">
                <li><a href="<?php echo e(route('index')); ?>/search?q=<?php echo e($q??''); ?>&__pgn=<?php echo e($pagin); ?>&dir=next">&laquo; Prev</a></li>
                
                <?php for($i=0;$i<$list;$i++): ?>
                <?php if(($i+1)*10-10 == $pagin-10): ?>
                <li><span style="color:black;"><?php echo e($i+1); ?></span></li>
                <?php else: ?>
                <li><a href="<?php echo e(route('index')); ?>/search?q=<?php echo e($q??''); ?>&__pgn=<?php echo e(($i+1)*10-10); ?>&dir=next"><?php echo e($i+1); ?></a></li>
                <?php endif; ?>
                <?php endfor; ?>
				<li><a href="<?php echo e(route('index')); ?>/search?q=<?php echo e($q??''); ?>&__pgn=<?php echo e($pagin); ?>&dir=prev">Next &raquo;</a></li>
            </ul>
            <?php endif; ?>
        </div>
        
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ipowerte/newstractor/resources/views/news/search.blade.php ENDPATH**/ ?>