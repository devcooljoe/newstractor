
<script>
    window.location.href = "<?php echo e(route('home')); ?>";
</script><?php /**PATH C:\project\portal\resources\views/auth/register.blade.php ENDPATH**/ ?>