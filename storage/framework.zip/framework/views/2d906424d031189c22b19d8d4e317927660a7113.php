<?php echo e($slot); ?>

<?php /**PATH C:\project\portal\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>