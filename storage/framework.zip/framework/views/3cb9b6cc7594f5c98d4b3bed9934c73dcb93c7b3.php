<?php $__env->startSection('title'); ?>
<title>Reset Your Password - Newstractor </title>
<link rel="stylesheet" type="text/css" href="/css/profile.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="profile">
	<h3 style="font-family: 'bebasregular'; word-spacing:5px;">Reset Your Password</h3>
	<div class="wrap">
		<div class="profile-main img-responsive">
			<form id="edit-profile-form" action="/password/reset" method="POST">
				<?php echo csrf_field(); ?>
				<div class="profile-pic wthree">
					<p class="text-left">
                        <span class="ababout">Enter a new password</span>
						<input type="password" name="password" id="username-input" class="abform">
						<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="has-error"><?php echo e($message ?? ''); ?></span>    
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						<span class="has-error"><?php echo e(Session::get('message') ?? ''); ?></span>
						<br>
						<span class="ababout">Comfirm password</span>
						<input type="password" name="password_confirmation" id="username-input" class="abform">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="has-error"><?php echo e($message ?? ''); ?></span>    
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</p>
				</div>
				<div class="w3-message">
					<p style="width: 100%">
						<input type="submit" id="edit-profile-button" style="width: 0px; height:0px; opacity:0;">
						<label id="edit-btn" for="edit-profile-button" class="pull-right btn btn-danger"
							style="color:black;">Submit</label></p>
				</div>
			</form>
		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ipowerte/newstractor/resources/views/auth/passwords/reset.blade.php ENDPATH**/ ?>