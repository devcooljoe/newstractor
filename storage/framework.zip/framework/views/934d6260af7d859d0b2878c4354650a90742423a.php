<?php $__env->startSection('title'); ?>
<title>Reset Your Password - Newstractor </title>
<link rel="stylesheet" type="text/css" href="/css/profile.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="profile">
	<div class="wrap">
		<div class="profile-main img-responsive">
			<form id="edit-profile-form" action="/password/email" method="POST">
				<?php echo csrf_field(); ?>
				<div class="profile-pic wthree">
					<p class="text-left">
                        <span class="ababout">Enter your E-mail</span>
                        <br>
                        <br>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e(Session::get('success') ?? ''); ?></strong>
                        </span>
						<input type="text" name="email" id="username-input" class="abform">
                        <span class="has-error" id="username-report"><?php echo e(Session::get('message') ?? ''); ?></span>
						<?php if(Session::has('success')): ?>
						<br>
                        <a href="/password/email/resend">Resend Reset Link?</a> <!-- Resend Password -->
                        <?php endif; ?>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="has-error" id="username-report"><?php echo e($message ?? ''); ?></span>    
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</p>
				</div>
				<div class="w3-message">
					<p style="width: 100%">
						<input type="submit" id="edit-profile-button" style="width: 0px; height:0px; opacity:0;">
						<label id="edit-btn" for="edit-profile-button" class="pull-right btn btn-danger"
							style="color:black;">Continue</label></p>
				</div>
			</form>
		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ipowerte/newstractor/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>