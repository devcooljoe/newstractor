

<script>
    window.location.href = "404";
</script><?php /**PATH /home/ipowerte/newstractor/resources/views/auth/login.blade.php ENDPATH**/ ?>