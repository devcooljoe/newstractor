<?php $thumbnail = str_replace('assets/post', 'assets/thumbnail', $post->file) ?>


<?php $__env->startSection('title'); ?>

<title><?php echo e($post->title); ?></title>
<link rel="stylesheet" type="text/css" href="/css/profile.css">
<link rel="canonical" href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" />
<meta name="keyword" content="<?php echo e(preg_replace('/ /', ', ',  $post->title)); ?>" />
<meta name="description" content="<?php echo e(substr($post->body, 0, 400)); ?>">
<meta property="og:locale" content="en_EN" />
<meta property="og:type" content="article" />
<meta property="og:title" content="<?php echo e($post->title); ?>" />
<meta property="og:description" content="<?php echo e(substr($post->body, 0, 400)); ?>" />
<meta property="og:url" content="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" />
<meta property="og:site_name" content="NewsTractor" />
<meta property="og:image" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail); ?>" />
<meta property="og:image:secure_url" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />
<meta property="og:image:width" content="800" />
<meta property="og:image:height" content="450" />
<meta property="og:image:alt" content="<?php echo e(substr($post->title, 0, 100)); ?>" />
<meta property="article:tag" content="<?php echo e(preg_replace('/ /', ', ',  substr($post->title, 0, 200))); ?>" />
<meta property="article:section" content="<?php echo e($post->category); ?>" />
<meta property="article:published_time" content="<?php echo e($post->created_at); ?>" />
<meta property="article:modified_time" content="<?php echo e($post->updated_at); ?>" />
<meta property="article:author" content="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>" />
<meta name="twitter:card" content="summary" />
<meta property="twitter:title" content="<?php echo e($post->title); ?>" />
<meta property="twitter:description" content="<?php echo e(substr($post->body, 0, 400)); ?>" />
<meta property="twitter:url" content="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" />
<meta property="twitter:image" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />
<meta property="twitter:image:width" content="800" />
<meta property="twitter:image:height" content="450" />
<meta property="twitter:image:alt" content="<?php echo e(substr($post->title, 0, 100)); ?>" />

<meta property="profile:username" content="<?php echo e($post->user->name ?? ''); ?>" />
<link rel="image_src" href="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />
<meta itemprop="image" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />
<meta name="msapplication-TileImage" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />

<!--webfont-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="blog-main-content">
    <div class="col-md-9 total-news">

        <div class="grids">
            <div class="grid box">
                <div class="grid-header">
                    <a class="gotosingle" href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e($post->title); ?></a>
                    <ul>
                        <li><span>Post by <a
                                    href="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>"><?php echo e($post->user->name); ?></a>
                                on <?php echo e(((explode('-', $post->date))[0])); ?> <?php echo e(((explode('-', $post->date))[1])); ?>

                                <?php echo e(((explode('-', $post->date))[2])); ?>, <?php echo e(((explode('-', $post->date))[3])); ?> </span>
                        </li>
                        <li><a href="#"><?php echo e($post->comment->count()); ?>

                                <?php echo e($post->comment->count()>1?'Comments':'Comment'); ?></a></li>
                    </ul>
                </div>
                <div class="singlepage">
                    <a href="#"><img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>"
                            alt="<?php echo e($post->title); ?>" /></a>   
                    <?php
                     $main = htmlspecialchars($post->body); 
                     $main = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" style="font-size:15px;">$1</a>', $main);
                     ?>

                    <p class="paragraph" style="color: #535353;font-size:15px;"><?php echo $main ?></p>
                    <div class="clearfix"></div>
                </div>
                <div class="comments">
                    <ul class="link-ul" style="display: flex; align-items:center;">
                        <?php if(auth()->guard()->check()): ?>
                        <li>
                            <strong id="like-count"><?php echo e($post->like->count()); ?>

                                <?php echo e($post->like->count()>1?'Likes':'Like'); ?></strong><a class="hvr-icon-bounce col-22"
                                style="cursor:pointer;" post="<?php echo e($post->id); ?>" title="Like" id="like">
                                <i id="like-font" style="font-size: 25px"
                                    class="fa <?php echo e($likepost?'fa-thumbs-up':'fa-thumbs-o-up'); ?> font-awesome font-awesome-like"></i>
                            </a>
                        </li>
                        <?php else: ?>
                        <li><strong id="like-count"><?php echo e($post->like->count()); ?>

                                <?php echo e($post->like->count()>1?'Likes':'Like'); ?></strong><a class="hvr-icon-bounce" href="#"
                                id="sub-a" title="Like Post">
                                <i style="font-size: 25px" class="fa fa-thumbs-o-up font-awesome font-awesome-like"></i>
                            </a></li>
                        <?php endif; ?>
                        <li><?php echo e($post->comment->count()); ?> <?php echo e($post->comment->count()>1?'Comments':'Comment'); ?><a
                                href="#comment" id="sub-a" title="Comments">
                                <i style="font-size: 25px" class="fa fa-comment-o font-awesome font-awesome-like"></i>
                            </a></li>
                        <!-- <li id="sh-phone">
                            <strong style="cursor:pointer;" onclick="sharePost()" title="Share Post">
                                <i style="font-size: 25px" onclick="sharePost()" class="fa fa-share font-awesome font-awesome-blue"></i>
                            </strong>
                        </li> -->
                        <script>
                            function sharePost() {
                            navigator.share({ 
                                    title: "<?php echo e($post->title); ?>",
                                    text: "",
                                    url: "<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>",
                           });
                            }
                        </script>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>
                        <li><a href="<?php echo e(route('index')); ?>/post/<?php echo e($post->id); ?>/edit" title="Edit Post">
                                <i style="font-size: 25px" class="fa fa-edit font-awesome-green"></i>
                            </a></li>
                        <li><a href="<?php echo e(route('index')); ?>/post/<?php echo e($post->id); ?>/delete" id="delete" title="Delete Post">
                                <i style="font-size: 25px" class="fa fa-trash-o font-awesome-red"></i>
                            </a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <div class="clearfix"> </div>
        </div>

        <div>
            <p>Like this article? Share with your friends.</p>
            <div class="social" style="margin: 10px;">
            <ul style="word-spacing: 2rem; text-align: center;">
               <li>
                  <a href="http://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('index').'/'.$post->custom_id); ?>" target="_blank">
                    <i class="fa fa-facebook" aria-hidden="true"></i> 
                  </a>
               </li>
               <li>
                <a href="http://twitter.com/share?url=<?php echo e(route('index').'/'.$post->custom_id); ?>%0A%0A<?php echo e(substr($post->body, 0, 150)); ?>" target="_blank">
                    <i class="fa fa-twitter" aria-hidden="true"></i> 
                </a>
               </li>
               <li>
                <a href="whatsapp://send?text=<?php echo e(urlencode(substr($post->body, 0, 150))); ?>%20<?php echo e(strlen($post->body)>150?'...':''); ?>%0A%0A<?php echo e(route('index').'/'.$post->custom_id); ?>" target="_blank">
                    <i class="fa fa-whatsapp" aria-hidden="true"></i> 
                </a>
               </li>
           </ul>
       </div>
        </div>
        <div class="story-review">
            <h4>REVIEW:</h4>
            <p> So,Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                been the industry's standard dummy text ever since the 1500s, when an unknown printer took a
                galley of type and scrambled it to make a type specimen book. It has survived not only five
                centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It
                was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum
                passages, and more recently with desktop publishing software like Aldus PageMaker including
                versions of Lorem Ipsum.
            </p>
        </div>

        <ul class="comment-list img-responsive">
            <h5 class="post-author_head">Written by <a
                    href="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>"
                    title="Posts by admin" rel="author"><?php echo e($post->user->name); ?></a></h5>
            <li class="list-com">
                <a href="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>"
                    title="View <?php echo e($post->user->name); ?>'s Profile">
                    <div class="img-cont img-responsive">
                        <img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->user->profile->avatar ?? 'assets/default/avatar.png'); ?>"
                            alt="<?php echo e($post->user->name); ?>" class="img-responsive" style="width: 150px">
                    </div>
                </a>
                <div class="desc img-reponsive" style="margin-left: 1rem;">

                    <p><span style="color: gray"><?php echo e($post->user->post->count()); ?>

                            <?php echo e($post->user->post->count()>1?'Articles':'Article'); ?>, <?php echo e($post->user->follow->count()); ?>

                            <?php echo e($post->user->follow->count()>1?'Followers':'Follower'); ?> </span><br> View all posts by:
                        <a href="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>#view"
                            title="Posts by admin" rel="author"><?php echo e($post->user->name); ?></a></p>
                </div>
                <div class="desc img-responsive" style="margin-left: 1rem">
                    <p style="font-size: 13px;"><?php echo e($post->user->profile->description ?? ''); ?></p>
                </div>
                <div class="clearfix"></div>
            </li>
        </ul>



        <h6 id="top"><br></h6>
        <?php if($postcomment->count()>0): ?>
        <h3 class="recent-comm">Recent Comments</h3>
        <?php endif; ?>
        <?php $i=$postcomment->count() ?>
        <?php $__currentLoopData = $postcomment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($i<=1): ?> <h6 id="comment"><br></h6>
            <?php endif; ?>
            <ul class="comment-list" style="padding: 5px; margin:0px;border:none;">
                <div class="media img img-responsive" id="media-div">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $comment)): ?>
                    <span id="del-link" onclick="delComm(<?php echo e($comment->id); ?>)">Delete</span>
                    <?php endif; ?>
                    <a href="<?php echo e(route('index')); ?>/profile/<?php echo e($comment->user->username ?? $comment->user->id); ?>"
                        title="View <?php echo e($comment->user->name); ?>'s Profile">
                        <img src="<?php echo e(route('index')); ?>/storage/<?php echo e($comment->user->profile->avatar ?? 'assets/default/avatar.png'); ?>"
                            id="media-object2" class="media-object img-thumbnail" alt="<?php echo e($comment->user->name); ?>">
                        <span id="name-span"><?php echo e($comment->user->name); ?><br></span>
                        <span id="date-span">
                            <?php echo e(((explode('-', $comment->date))[0])); ?> <?php echo e(((explode('-', $comment->date))[1])); ?>

                            <?php echo e(((explode('-', $comment->date))[2])); ?>, <?php echo e(((explode('-', $comment->date))[3])); ?>

                        </span><br>
                    </a>
                    <div class="media-body" id="media-body-div">
                        <?php
                         $main = htmlspecialchars($comment->comment); 
                         $main = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" style="font-size:15px;">$1</a>', $main);
                         ?>
                        <p id="com-pre"><?php echo $main ?></p>
                    </div>
                </div>
            </ul>
            <?php $i-- ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <!-- Pagination -->
            <?php if($post->comment->count()>5): ?>
            <div style="margin-right: 4rem;">
                <ul class="pagination">
                    <li><a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>?__pgn=<?php echo e($pagin); ?>&dir=prev#top">&laquo;
                            Prev</a></li>
                    <li><a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>?__pgn=<?php echo e($pagin); ?>&dir=next#top">Next
                            &raquo;</a></li>
                </ul>
            </div>
            <?php endif; ?>

            <div class="content-form">
                <h3>Leave a comment</h3>
                <form action="/comment/<?php echo e($post->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <textarea placeholder="Comment here.." name="comment" maxlength="2000"></textarea>
                    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="has-error"><?php echo e($message); ?></span><br><br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if(auth()->guard()->check()): ?>
                    <input type="submit" value="SEND" />
                    <?php else: ?>
                    <input type="submit" value="SEND" id="sub-b" />
                    <script>
                    $('#sub-b').click(function(e) {
                        e.preventDefault();
                        $('#modal_trigger').trigger('click');
                    });
                    $('#sub-a').click(function(e) {
                        e.preventDefault();
                        $('#modal_trigger').trigger('click');
                    });
                    </script>
                    <?php endif; ?>

                </form>
            </div>
    </div>

    <div class="col-md-3 side-bar">
        <div class="l_g_r">
            <?php if($mightlike->count()>0): ?>
            <div class="might">
                <h4>You might also like</h4>
                <?php $__currentLoopData = $mightlike; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="might-grid">
                    <div class="grid-might">
                        <a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><img
                                src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" class="img-responsive"
                                alt="<?php echo e($post->title); ?>" /></a>
                    </div>
                    <div class="might-top">
                        <p>
                            <?php echo e(substr($post->title, 0, 50)); ?>

                            <?php echo e(strlen($post->title)>50?'...':''); ?>

                        </p>
                        <a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More<i> </i></a>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if($featured->count()>0): ?>
            <div class="featured">
                <h3>Featured News</h3>
                <ul>
                    <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">
                            <div class="video" style="border: 2px solid white;overflow:hidden">
                                <img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>"
                                    class="img-responsive">
                            </div>
                        </a>
                        <p>
                            <?php echo e(substr($post->title, 0, 10)); ?><?php echo e(strlen($post->title)>10?'...':''); ?>

                        </p>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="clearfix"></div>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($popular->count()>0): ?>
            <div class="popular mpopular">
                <div class="main-title-head">
                    <h5>popular</h5>
                    <h4> Most read</h4>
                    <div class="clearfix"></div>
                </div>
                <div class="popular-news">
                    <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="popular-grid">
                        <i>
                            <?php echo e(((explode('-', $post->date))[0])); ?> <?php echo e(((explode('-', $post->date))[1])); ?>

                            <?php echo e(((explode('-', $post->date))[2])); ?>, <?php echo e(((explode('-', $post->date))[3])); ?>

                        </i>
                        <p><?php echo e(substr($post->title, 0, 70)); ?>

                            <?php echo e(strlen($post->title)>70?'...':''); ?>

                            <a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a>
                        </p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if($recentpost->count()>0): ?>
            <div class="posts">
                <h4>Recent posts</h4>
                <?php $__currentLoopData = $recentpost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h6 style="margin-bottom: 1rem;"><a
                        href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e(substr($post->title, 0, 50)); ?>

                        <?php echo e(strlen($post->title)>50?'...':''); ?></a></h6>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <?php if($recentcomment->count()>0): ?>
            <div class="recent-comments">
                <h4>Recent Comments</h4>
                <?php $__currentLoopData = $recentcomment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h6 style="margin-bottom: 1rem;"><a href="<?php echo e(route('index')); ?>/<?php echo e($comment->post->custom_id); ?>">
                        <?php echo e(substr($comment->comment, 0, 30)); ?>

                        <?php echo e(strlen($comment->comment)>30?'...':''); ?>

                        <span>on</span>
                        <?php echo e(substr($comment->post->title, 0, 30)); ?>

                        <?php echo e(strlen($comment->post->title)>30?'...':''); ?>

                    </a></h6>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

        </div>
    </div>
    <div class="clearfix"></div>
</div>
<script>
document.getElementById('delete').addEventListener('click', function(e) {
    e.preventDefault();
    var conf = confirm('Do you really want to delete this post?');
    if (conf == true) {
        location.href = this.href;
    }
});
</script>
<script>
function delComm(id) {
    var conf = confirm('Do you really want to delete this comment?');
    if (conf == true) {
        location.href = '/comment/' + id + '/delete';
    }
}
</script>
<script>
$('#like').click(function(e) {
    e.preventDefault();
    var like = $('#like-font');
    if (like.hasClass('fa-thumbs-up')) {
        like.removeClass('fa-thumbs-up').addClass('fa-thumbs-o-up');
    } else {
        like.removeClass('fa-thumbs-o-up').addClass('fa-thumbs-up');
    }
    var id = $(this).attr('post');
    xhr = new XMLHttpRequest();
    xhr.open('GET', '/post/' + id + '/like');
    xhr.onload = function() {
        if (this.status == 200) {
            var response = JSON.parse(this.responseText);
            $('#like-count').html(response.count + ' ' + response.react);
        }
    }
    xhr.send();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\newstractor\resources\views/news\singlepage.blade.php ENDPATH**/ ?>