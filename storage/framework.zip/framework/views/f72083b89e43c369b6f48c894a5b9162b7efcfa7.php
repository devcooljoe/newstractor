

<?php $__env->startSection('title'); ?>
<link href="/css/font-awesome.css" rel="stylesheet" type="text/css" media="all" />
<link href="/css/profile.css" rel="stylesheet" type="text/css" media="all" />
<title>The News Reporter a Magazine Category Flat Bootstarp Responsive Website Template| Home :: w3layouts</title>
<meta name="keywords" content="The keywords" />
<meta name="description" content="The description">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Creative Design Profile</h1>
<div class="profile">
	<div class="wrap">
		<div class="profile-main img-responsive">
			<div class="profile-pic wthree">
				<p style="width: 100%">
					<a href="/profile/<?php echo e(auth()->user()->id); ?>/edit" class="pull-right btn btn-primary" style="color:black;"><i class="fa fa-edit"></i> Edit</a></p>
				<br><br><br>
				<img src="/images/4.jpg" alt="">
				<h2>SHANE WATSON</h2>
				<p>News Reporter <strong>(ADMIN)</strong></p>
			</div>
			<div class="w3-message">
				<h5>About Me</h5>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec erat sapien, lobortis id felis eu,
					egestas venenatis nisl.</p>
				<div class="w3ls-touch">

					<div class="social">
						<ul>
							<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i> </a></li>
							<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> </a></li>
							<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i> </a></li>
							<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i> </a></li>
						</ul>
					</div>
				</div>
			</div>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\newstractor\resources\views/user/profile.blade.php ENDPATH**/ ?>