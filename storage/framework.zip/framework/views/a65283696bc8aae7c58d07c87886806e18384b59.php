<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Post</title>
</head>
<body>
    
</body>
</html><?php /**PATH C:\project\portal\resources\views/admin\post\new.blade.php ENDPATH**/ ?>