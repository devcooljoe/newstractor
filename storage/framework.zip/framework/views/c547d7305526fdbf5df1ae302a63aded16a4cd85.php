

<script>
    window.location.href = "404";
</script><?php /**PATH C:\project\portal\resources\views/auth/login.blade.php ENDPATH**/ ?>