<?php $user->profile->avatar == null?$thumbnail='':$thumbnail = str_replace('assets/avatar/', 'assets/thumbnail/', $user->profile->avatar) ?>


<?php $__env->startSection('title'); ?>

<title>
	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?> Your Profile <?php else: ?> <?php echo e($user->name); ?>'s Profile <?php endif; ?> - News Tractor
</title>
<link rel="stylesheet" type="text/css" href="/css/profile.css">
<link rel="canonical" href="<?php echo e(route('index')); ?>/" />
<meta name="keyword" content="<?php echo e($user->name); ?>, <?php echo e(preg_replace('/ /', ', ',  $user->profile->title)); ?>" />
<meta name="description" content="<?php echo e($user->profile->description); ?>">
<meta property="og:locale" content="en_EN" />
<meta property="og:type" content="profile" />
<meta property="og:title" content="<?php echo e($user->name); ?> - <?php echo e($user->profile->title); ?>" />
<meta property="og:description" content="<?php echo e($user->profile->description); ?>" />
<meta property="og:url" content="<?php echo e(route('index')); ?>/profile/<?php echo e($user->username ?? $user->id); ?>" />
<meta property="og:site_name" content="NewsTractor" />
<meta property="og:image" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />
<meta property="og:image:secure_url" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />
<meta property="og:image:width" content="800" />
<meta property="og:image:height" content="450" />
<meta property="og:image:alt" content="<?php echo e($user->name); ?>" />
<meta property="article:tag" content="<?php echo e($user->name); ?>, <?php echo e(preg_replace('/ /', ', ',  $user->profile->title)); ?>" />
<meta property="article:section" content="" />
<meta property="article:published_time" content="<?php echo e($user->profile->created_at); ?>" />
<meta property="article:modified_time" content="<?php echo e($user->profile->updated_at); ?>" />
<meta property="article:author" content="<?php echo e($user->name); ?>" />
<meta name="twitter:card" content="summary" />
<meta property="twitter:title" content="<?php echo e($user->name); ?> - <?php echo e($user->profile->title); ?>" />
<meta property="twitter:description" content="<?php echo e($user->profile->description); ?>" />
<meta property="twitter:url" content="<?php echo e(route('index')); ?>/profile/<?php echo e($user->username ?? $user->id); ?>" />
<meta property="twitter:image" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />
<meta property="twitter:image:width" content="800" />
<meta property="twitter:image:height" content="450" />
<meta property="twitter:image:alt" content="<?php echo e($user->profile->title); ?>" />

<meta property="profile:username" content="<?php echo e($user->username); ?>" />
<link rel="image_src" href="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />
<meta itemprop="image" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />
<meta name="msapplication-TileImage" content="<?php echo e(route('index')); ?>/storage/<?php echo e($thumbnail ?? ''); ?>" />

<!--webfont-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="main-content">

	<div class="col-md-9 total-news">
		<div class="classifieds bg-profile">
			<h3>
				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?> Your Profile <?php else: ?> <?php echo e($user->name); ?>'s Profile <?php endif; ?>
			</h3>
			<div class="profile">
				<div class="wrap">
					<div class="profile-main img-responsive">
						<div class="profile-pic wthree">
							<p style="width: 100%">
							<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
								<a href="<?php echo e(route('index')); ?>/profile/<?php echo e($user->username ?? $user->id); ?>/edit"
									class="pull-right btn btn-danger btn-sm" style="color:black;"><i
										class="fa fa-edit"></i>
									Edit</a></p>
							<?php else: ?>
								<?php if($user->admin()): ?>
								<?php if(auth()->guard()->check()): ?>
								<div class="pull-right">
								 <button class="btn btn-danger followBtn" id="followBtn"><?php echo e($button); ?></button>
								</div>
								<?php else: ?>
								<div class="pull-right">
								 <button class="btn btn-danger" id="followBtn2">Follow</button>
								</div>
								<?php endif; ?>
								<?php endif; ?>
							<?php endif; ?>
							<script type="text/javascript">
								$('#followBtn2').click(function(){
									$('#modal_trigger').trigger('click');
								});
							</script>
							<br><br><br>
							<center>
								<div class="img-cont">
									<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($user->profile->avatar ?? 'assets/default/avatar.png'); ?>"
										alt="<?php echo e($user->name); ?>">
								</div>
							</center>


							<?php if($user->admin()): ?>
							<div class="" style="align-items: top;">
								<strong class="label label-primary pull-left" id="followText"><?php echo e($follower); ?> <?php echo e($follower>1?'Followers':'Follower'); ?></strong>
								<strong class="label label-primary pull-right"><?php echo e($following); ?> <?php echo e(__('Following')); ?></strong>
							</div>
							<?php endif; ?>
							<div class="clearfix"></div>
							<h2 style="position: relative;top: -1rem;"><?php echo e($user->name); ?></h2>
							<p style="position: relative;top: -1rem;"><?php if($user->admin()): ?> <?php echo e($user->profile->role); ?> <?php endif; ?>
								<?php if($user->profile->role == null && $user->admin()): ?>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
								Edit Profile to add Role
								<?php endif; ?>
								<?php endif; ?>
								<br><strong><?php echo e(($user->admin()?'(ADMIN)':'')); ?></strong>
							</p>
						</div>
						<div class="w3-message" style="position: relative;top: -1rem;">
							<h5>
								<?php echo e($user->profile->title); ?>

								<?php if($user->profile->title == null): ?>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
								Edit Profile to add Title
								<?php endif; ?>
								<?php endif; ?>
							</h5>
							<p class="paragraph"><?php echo e($user->profile->description); ?>

								<?php if($user->profile->description == null): ?>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
								Edit Profile to add Description
								<?php endif; ?>
								<?php endif; ?>
							</p>
							<div class="w3ls-touch">

								<div class="social">
									<ul>
										<?php if($user->profile->facebook != null): ?>
										<li><a href="<?php echo e($user->profile->facebook); ?>" target="_blank"><i
													class="fa fa-facebook" aria-hidden="true"></i> </a></li>
										<?php endif; ?>
										<?php if($user->profile->twitter != null): ?>
										<li><a href="<?php echo e($user->profile->twitter); ?>" target="_blank"><i
													class="fa fa-twitter" aria-hidden="true"></i> </a></li>
										<?php endif; ?>
										<?php if($user->profile->instagram != null): ?>
										<li><a href="<?php echo e($user->profile->instagram); ?>" target="_blank"><i
													class="fa fa-instagram" aria-hidden="true"></i> </a></li>
										<?php endif; ?>



										<!-- <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i> </a></li> -->
									</ul>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>


		</div>

		<?php if($user->admin()): ?>
		<span style="margin-bottom: 1rem;" id="view"><br></span>
		<div class="classifieds author-padding">
			<div class="main-title-head">
				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
				<h3>Your latest posts</h3>
				<?php else: ?>
				<h3>latest posts by <?php echo e($user->name); ?></h3>
				<?php endif; ?>
				<div class="clearfix"></div>
			</div>
			<div class="world-news-grids">
				<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="world-news-grid img-responsive">
					<div class="img-cont-post img-responsive">
						<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>"
							class="img-responsive" />
					</div>
					<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"
						class="title"><?php echo e(strlen($post->title)>50?substr($post->title, 0, 50).' ...':$post->title); ?></a>
					<p><?php echo e(strlen($post->body)>95?substr($post->body, 0, 95).'...':$post->body); ?></p>
					<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<?php endif; ?>
	</div>
	<div class="clearfix visible-xs"></div>
	<div class="col-md-3 side-bar">
		<div class="videos">
			<?php $__currentLoopData = $maylike; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="video-grid">
				<div class="video" style="border: 2px solid white;">
					<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>">
				</div>
				<div class="video-name">
					<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">
						<?php echo e(substr($post->title, 0, 50)); ?>

						<?php echo e(strlen($post->title)>50?'...':''); ?>

					</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<a class="more1" href="<?php echo e(route('index')); ?>/">More +</a>
			<div class="clearfix"></div>
		</div>
		<div class="sign_up text-center" id="subscribe">
			<h3>Sign Up for Newsletter</h3>
			<p class="sign">Sign up to receive our free newsletters!</p>
			<form>
				<input type="text" class="text" value="Name" onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'Name';}">
				<input type="text" class="text" value="Email Address" onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'Email Address';}">
				<input type="submit" value="submit">
			</form>
			<p class="spam">We do not spam. We value your privacy!</p>
		</div>
		<div class="clearfix"></div>
		<div class="popular">
			<div class="main-title-head">
				<h5>popular</h5>
				<h4> Most read</h4>
				<div class="clearfix"></div>
			</div>
			<div class="popular-news">
				<?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="popular-grid">
					<i>
						<?php echo e(((explode('-', $post->date))[0])); ?> <?php echo e(((explode('-', $post->date))[1])); ?>

						<?php echo e(((explode('-', $post->date))[2])); ?>, <?php echo e(((explode('-', $post->date))[3])); ?>

					</i>
					<p><?php echo e(substr($post->title, 0, 70)); ?>

						<?php echo e(strlen($post->title)>70?'...':''); ?>

						<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a></p>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<a class="more" href="<?php echo e(route('index')); ?>/">More +</a>
			</div>
		</div>
		<div class="subscribe-now">
			<div class="discount">
				<a href="#subscribe">
					<div class="save">
						<p>Save</p>
						<p>upto</p>
					</div>
					<div class="percent">
						<h2>50%</h2>
					</div>
					<div class="clearfix"></div>
			</div>
			<h3 class="sn">subscribe now</h3>
			</a>
		</div>
		<div class="clearfix"></div>
	</div>
	<div class="clearfix"></div>
</div>

<script type="text/javascript">
	$('#followBtn').click(function(){

		var btn = $('#followBtn');

		if (btn.html() == 'Follow') {
			btn.html('Unfollow');
		}else{
			btn.html('Follow');
		}

		var id = <?php echo e($user->id); ?>;
		xhr = new XMLHttpRequest();
		xhr.open('GET', '/profile/'+id+'/follow', true);
		xhr.onload = function () {
			if (this.status == 200) {
				var response = JSON.parse(this.responseText);
				$('#followText').html(response.count+' '+response.follow);
				btn.html(response.status);
			}
		}
		xhr.send();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\newstractor\resources\views/user\profile.blade.php ENDPATH**/ ?>