 

<?php $__env->startSection('title'); ?>
<title>Add New Post - News Tractor</title>
<meta name="keywords" content="The keywords" />
<meta name="description" content="The description">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="cont-margin">
    	<div class="jumbotron row jumbo1">
	        <div class="col col-lg-3 col-md-3 col-sm-3 col-xs-12 hidden-xs"><br></div>
	        <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-12">
	        	<div style="display:flex;">
				<h3>Add New Post</h3>
				<p class="text-right" style="margin-left:3px;"><b><a class="ababout" href="#" onclick="showHint()">Hint</a></b></p>
				</div>
				<form action="/post/store" method="post" enctype="multipart/form-data" autocomplete="off">
				<?php echo csrf_field(); ?>
				<span class="ababout">Title</span>
				<input class="abform" type="text" value="<?php echo e(old('title')); ?>" name="title" maxlength="500">
				<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="has-error"><?php echo e($message); ?></span><br><br>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<br>
				<span class="ababout">Body</span>
				<textarea class="abform" name="body" cols="30" rows="10" maxlength="10000"><?php echo e(old('body')); ?></textarea>
				<?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  
				<span class="has-error"><?php echo e($message); ?></span><br><br>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>				
				<br>
				<span class="ababout">Category</span>
				<select name="category" id="" class="abform">
					<option value="">Select the Post Category</option>
					<option value="sports">Sports</option>
					<option value="tech">Tech</option>
					<option value="business">Business</option>
					<option value="gist">Gist/Gossip</option>
					<option value="entertainment">Entertainment</option>
					<option value="campus">Campusnews</option>
					<option value="politics">Politics</option>
					<option value="blogs">Blogs</option>
				</select>
				<?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="has-error"><?php echo e($message); ?></span><br><br>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<br>
				<br>
				<span class="ababout">Picture</span>
				<input class="btn" type="file" name="file" id="file" style="width:100%">
				<?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="has-error"><?php echo e($message); ?></span><br><br>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<br>
				<br>
				<input type="submit" value="Post" class="sub-btn">
			</form>
	        </div>
	        <div class="col col-lg-3 col-md-3 col-sm-3 col-xs-12 hidden-xs"><br></div>
    	</div>
	</div>
	
	<script>
		var link = "https://www.google.com/webmasters/sitemaps/ping?sitemap=<?php echo e(route('index')); ?>/sitemap.xml";
		var xhr = new XMLHttpRequest();
		xhr.open('GET',link,true);
		xhr.send();
	</script>
	<script>
	function showHint() {
		
		alert("To place a word or sentence in centre: \n 👉 #cen Sentence ##cen");
		alert("To make a word or sentence Bold: \n 👉 #b Sentence ##b");
		alert("To make a word or sentence Itallic: \n 👉 #i Sentence ##i");
		alert("To make a word or sentence underline: \n 👉 #u Sentence ##u");
		alert("To make an horizontal line: \n use #l");
	    alert('To create a code: \n 👉 #c Sentence ##c for normal code. \n #ch Sentence ##ch for html \n \n #cc Sentence ##cc for css \n #cj Sentence ##cj for js ');
	    alert('To create an hyperlink: \n 👉 #a Url a# display sentence ##a ');
	    alert('To add an image: \n 👉 #img Picture name img# Picture Url ##img ');
	    

	}
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ipowerte/newstractor/resources/views/admin/post/new.blade.php ENDPATH**/ ?>