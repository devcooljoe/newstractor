<?php $__env->startSection('title'); ?>
<title>Notification - Newstractor</title>
<link rel="stylesheet" type="text/css" href="/css/profile.css">
<meta name="keyword" content="newstractor, news, politics, breaking news, updates, trending" />
<meta name="description"
    content="Newstractor Keep you up with global news updates, trends, local news, etc.. We are building the best global community and will want you to be part.">
<meta property="og:locale" content="en_EN" />
<meta property="og:type" content="article" />
<meta property="og:title" content=" Newstractor - Global Breaking news updates, Latest news headlines" />
<meta property="og:description"
    content="Newstractor Keep you up with global news updates, trends, local news, etc.. We are building the best global community and will want you to be part." />
<meta property="og:url" content="<?php echo e(route('index')); ?>" />
<meta property="og:site_name" content="Newstractor" />
<meta property="og:image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="og:image:secure_url" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="og:image:width" content="800" />
<meta property="og:image:height" content="450" />
<meta property="og:image:alt" content="" />
<meta property="article:tag" content="about, news, headlines, Newstractor" />
<meta property="article:section" content="" />
<meta property="article:published_time" content="" />
<meta property="article:modified_time" content="" />
<meta property="article:author" content="" />
<meta name="twitter:card" content="summary" />
<meta property="twitter:title" content="Newstractor - Global Breaking news updates, Latest news headlines" />
<meta property="twitter:description"
    content="Newstractor Keep you up with global news updates, trends, local news, etc.. We are building the best global community and will want you to be part." />
<meta property="twitter:url" content="" />
<meta property="twitter:image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="twitter:image:width" content="800" />
<meta property="twitter:image:height" content="450" />
<meta property="twitter:image:alt" content="" />

<meta property="profile:username" content="" />
<link rel="image_src" href="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta itemprop="image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta name="msapplication-TileImage" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="profile">
    <div class="wrap">
        <br>
        <h3 class="search-result-head">
            Your Notifications
        </h3>

        <div class="profile-main img-responsive" style="width:700px;box-shadow:none;">
            <?php if($results->count()<1): ?> 
            <h4 class="search-result-head text-center">
                You don't have any Notification yet!
            </h4>
                <?php else: ?>
                <?php $eq=0; ?>
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="result-s mg-top <?php if($notification->status != 'read'): ?> result-r <?php endif; ?>">
                    <?php if($notification->status != 'read'): ?><span class="bullet">&bullet;</span><?php endif; ?>
                    <a href="<?php echo e(route('index')); ?>/notification/<?php echo e($notification->id); ?>/mark/?link=<?php echo e(route('index')); ?><?php echo e($notification->link); ?>"
                        class="search-head">
                        <h4><?php echo e($notification->message); ?></h4>
                    </a>
                    <button class="badge pull-right" style="margin-left: 1rem; margin-top:5px; position:relative; bottom:5px; outline:none;" onclick="mark(<?php echo e($notification->id); ?>, <?php echo e($eq); ?>)">Mark as Read</button>
                    <span class="notidate" style="color: #696969"><?php echo e(\App\Custom::customdate($notification->date)); ?></span>
                
                    
                </div>
                <?php $eq++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>


                <?php if($resultcount>20): ?>
                <p class="text-center"><a class="btn btn-danger" href="<?php echo e(route('index')); ?>/notification?__pgn=<?php echo e($r); ?>&dir=more">See More</a></p>
                <?php endif; ?>
        </div>

    </div>
</div>


<script type="text/javascript">
    function mark(id, eq) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', '/notification/'+id+'/ajaxMark', true);
        xhr.onload = function () {
            if (this.status == 200) {
                $('.mg-top').eq(eq).removeClass('result-r');
            }
        }
        xhr.send();
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ipowerte/newstractor/resources/views/user/notification.blade.php ENDPATH**/ ?>