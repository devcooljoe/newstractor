


<?php $__env->startSection('title'); ?>

<title>Newstractor - Global Breaking news updates, Latest news headlines | Blogs </title>
<meta name="keyword" content="newstractor, news, politics, breaking news, updates, trending" />
<meta name="description" content="Newstractor Keep you up with global news updates, trends, local news, etc.. We are building the best global community and will want you to be part.">
<meta property="og:locale" content="en_EN" />
<meta property="og:type" content="article" />
<meta property="og:title" content=" Newstractor - Global Breaking news updates, Latest news headlines" />
<meta property="og:description" content="Newstractor Keep you up with global news updates, trends, local news, etc.. We are building the best global community and will want you to be part." />
<meta property="og:url" content="<?php echo e(route('blogs')); ?>" />
<meta property="og:site_name" content="Newstractor" />
<meta property="og:image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="og:image:secure_url" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="og:image:width" content="800" />
<meta property="og:image:height" content="450" />
<meta property="og:image:alt" content="" />
<meta property="article:tag" content="about, news, headlines, Newstractor" />
<meta property="article:section" content="" />
<meta property="article:published_time" content="" />
<meta property="article:modified_time" content="" />
<meta property="article:author" content="" />
<meta name="twitter:card" content="summary" />
<meta property="twitter:title" content="Newstractor - Global Breaking news updates, Latest news headlines" />
<meta property="twitter:description" content="Newstractor Keep you up with global news updates, trends, local news, etc.. We are building the best global community and will want you to be part." />
<meta property="twitter:url" content="" />
<meta property="twitter:image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="twitter:image:width" content="800" />
<meta property="twitter:image:height" content="450" />
<meta property="twitter:image:alt" content="" />

<meta property="profile:username" content="" />
<link rel="image_src" href="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta itemprop="image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta name="msapplication-TileImage" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="blog-main-content">
	<div class="col-md-9 total-news">
		<!----start-content----->
		<div class="content">
			<div class="grids">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $post->body = \App\Custom::filterPost($post->body) ?>
				<div class="grid box">
					<div class="grid-header">
						<a class="gotosingle" href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e($post->title); ?></a>
						<ul>
							<li><span>Post by <a href="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>"> <?php echo e($post->user->name); ?></a> <?php echo e(\App\Custom::customdate($post->date)); ?> </span></li>
							<li><a href="#"><?php echo e($post->comment->count()); ?>

                                <?php echo e($post->comment->count()>1?'Comments':'Comment'); ?></a></li>
						</ul>
					</div>
					<div class="grid-img-content">
						<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" class="blog img-responsive" alt="<?php echo e($post->title); ?>" style="width:400px;" /></a>
						<p><?php echo e(substr(($post->body), 0, 500)); ?> <?php echo e(strlen($post->body)>500?'...':''); ?></p>
						<div class="clearfix"> </div>
					</div>
					<div class="comments">
						<ul>
							<li><a class="readmore" href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">ReadMore</a></li>
						</ul>
					</div>
				</div>
				<hr>
				<br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<div class="clearfix"></div>
			<div class="content-pagenation">
				<li><a href="<?php echo e(route('search')); ?>/?q=blogs">&laquo; Prev</a></li>
				<li><a href="<?php echo e(route('search')); ?>/?q=blogs">1</a></li>
				<li><a href="<?php echo e(route('search')); ?>/?q=blogs">2</a></li>
				<li><a href="<?php echo e(route('search')); ?>/?q=blogs">3</a></li>
				<li><span>....</span></a></li>
				<li><a href="<?php echo e(route('search')); ?>/?q=blogs">Next &raquo;</a></li>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>

		</div>
	</div>
	<div class="col-md-3 side-bar">
        <div class="l_g_r">
            <?php if($mightlike->count()>0): ?>
            <?php $post->body = \App\Custom::filterPost($post->body) ?>
            <div class="might">
                <h4>Blogs You Might Like</h4>
                <?php $__currentLoopData = $mightlike; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="might-grid">
                    <div class="grid-might">
                        <a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" title=""><img
                                src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" class="img-responsive"
                                alt="<?php echo e($post->title); ?>" /></a>
                    </div>
                    <div class="might-top">
                        <p>
                            <?php echo e(substr($post->title, 0, 50)); ?>

                            <?php echo e(strlen($post->title)>50?'...':''); ?>

                        </p>
                        <a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" title="">Read More<i> </i></a>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if($featured->count()>0): ?>
            <?php $post->body = \App\Custom::filterPost($post->body) ?>
            <div class="featured">
                <h3>Featured Blogs</h3>
                <hr>
                <ul>
                    <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" title="">
                            <div class="video" style="border: 2px solid white;overflow:hidden">
                                <img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>"
                                    class="img-responsive">
                            </div>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="clearfix"></div>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($popular->count()>0): ?>
            <?php $post->body = \App\Custom::filterPost($post->body) ?>
            <div class="popular mpopular">
                <div class="main-title-head">
                    <h5>popular</h5>
                    <h4> Blogs</h4>
                    <div class="clearfix"></div>
                </div>
                <div class="popular-news">
                    <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="popular-grid">
                        <i>
                            <?php echo e(\App\Custom::customdate($post->date)); ?>

                        </i>
                        <p><?php echo e(substr($post->title, 0, 70)); ?>

                            <?php echo e(strlen($post->title)>70?'...':''); ?>

                            <a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" title="">Read More</a>
                        </p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

		</div>
	</div>
	<div class="clearfix"></div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ipowerte/newstractor/resources/views/news/blogs.blade.php ENDPATH**/ ?>