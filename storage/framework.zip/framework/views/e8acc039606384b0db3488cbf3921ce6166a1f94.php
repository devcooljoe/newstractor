

<?php $__env->startSection('title'); ?>
<title>The News Reporter a Magazine Category Flat Bootstarp Responsive Website Template| Home :: w3layouts</title>
<meta name="keywords" content="The keywords" />
<meta name="description" content="The description">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\newstractor\resources\views/user/editadmin.blade.php ENDPATH**/ ?>