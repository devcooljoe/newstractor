


<?php $__env->startSection('title'); ?>

<title>The News Reporter a Magazine Category Flat Bootstarp Responsive Website Template| Home :: w3layouts</title>
<meta name="keywords" content="The keywords" />
<meta name="description" content="The description">
<!--webfont-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="main-content">
	<div class="contact-section">
		<div class="contact-section-head">
			<h3>Contact us</h3>
		</div>
		<br>
		<div class="contact-form-bottom">
			<div class="col-md-4 address">
				<address>
					<h5><br></h5>
					<p><br></p>
					<p><br></p>
					<p class="bottom"><br></p>
					<h5><br></h5>
					<p><br></p>
				</address>
			</div>
			<div class="col-md-4 contact-form">
				<form>
					<div class="contact-form-row">
						<div>
							<span>Name</span>
							<input type="text" class="text" value="" onfocus="this.value = '';"
								onblur="if (this.value == '') {this.value = '';}">
						</div>
						<div>
							<span>Email</span>
							<input type="text" class="text" value="" onfocus="this.value = '';"
								onblur="if (this.value == '') {this.value = '';}">
						</div>
						<div>
							<span>Phone</span>
							<input type="text" class="text" value="" onfocus="this.value = '';"
								onblur="if (this.value == '') {this.value = '';}">
						</div>
						<input type="submit" value="Submit" />
						<div class="clearfix"> </div>
					</div>
				</form>
			</div>
			<div class="col-md-4 contact-form-row ccomments">
				<div>
					<span>Enter text</span>
					<textarea value="" onfocus="this.value = '';"
						onblur="if (this.value == '') {this.value = '';}"></textarea>
				</div>
				<div>
					<span>Security</span>
					<img src="images/security.jpg" class="code" alt="" />
					<input type="text" class="text" value="" onfocus="this.value = '';"
						onblur="if (this.value == '') {this.value = '';}">
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\newstractor\resources\views/news/contact.blade.php ENDPATH**/ ?>