


<?php $__env->startSection('title'); ?>

<title>The News Reporter a Magazine Category Flat Bootstarp Responsive Website Template| Home :: w3layouts</title>
<meta name="keywords" content="The keywords" />
<meta name="description" content="The description">
<!--webfont-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="blog-main-content">
	<div class="col-md-9 total-news">

		<div class="grids">
			<div class="grid box">
				<div class="grid-header">
					<a class="gotosingle" href="singlepage">Lorem ipsum dolor sit amet, consectetur adipisicing
						elit, sed do eiusmod . </a>
					<ul>
						<li><span>Post by<a href="#"> Admin</a> on sunday, March 05, 2015 </span></li>
						<li><a href="#">5 comments</a></li>
					</ul>
				</div>
				<div class="singlepage">
					<a href="#"><img src="images/grid-img.jpg" /></a>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,Sed ut perspiciatis unde omnis iste
						natus error sit voluptatem accusantium perspiciatis unde omnis iste natus error sit voluptatem
						accusantiumdoloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis
						et quasi architecto beatae vitae dicta sunt explicabo. sed do eiusmod tempor incididunt ut
						labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
						laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
						voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
						non proident, sunt in culpa qui officia deserunt mollit anim id est laborum<a href="#">...</a>
					</p>
					<div class="clearfix"> </div>
				</div>
				<div class="comments">
					<ul>
						<li><a href="#"><img src="images/views.png" title="view" /></a></li>
						<li><a href="#"><img src="images/likes.png" title="likes" /></a></li>
						<li><a href="#"><img src="images/link.png" title="link" /></a></li>
					</ul>
				</div>
			</div>

			<div class="clearfix"> </div>
		</div>

		<ul class="comment-list">
			<h5 class="post-author_head">Written by <a href="#" title="Posts by admin" rel="author">admin</a></h5>
			<li><img src="images/avatar.png" class="img-responsive" alt="">
				<div class="desc">
					<p>View all posts by: <a href="#" title="Posts by admin" rel="author">admin</a></p>
				</div>
				<div class="clearfix"></div>
			</li>
		</ul>
		<div class="content-form">
			<h3>Leave a comment</h3>
			<form>
				<input type="text" placeholder="Name" required />
				<input type="text" placeholder="Email" required />
				<input type="text" placeholder="Phone" required />
				<textarea placeholder="Message"></textarea>
				<input type="submit" value="SEND" />
			</form>
		</div>
	</div>

	<div class="col-md-3 side-bar">
		<div class="l_g_r">
			<div class="posts">
				<h4>Recent posts</h4>
				<h6><a href="#">Aliquam tincidunt mauris</a></h6>
				<h6><a href="#">Vestibulum auctor lipsum</a></h6>
				<h6><a href="#">Nunc dignissim risus</a></h6>
				<h6><a href="#">Cras ornare tristiqu</a></h6>
			</div>
			<div class="recent-comments">
				<h4>Recent Comments</h4>
				<h6><a href="#">Amada Doe <span>on</span> Hello World!</a></h6>
				<h6><a href="#">Peter Doe <span>on</span> Photography</a></h6>
				<h6><a href="#">Steve Roberts <span>on</span> HTML5/CSS3</a></h6>
				<h6><a href="#">Doe Peter<span>on</span> Photography</a></h6>
			</div>
			<div class="archievs">
				<h4>Archives</h4>
				<h6><a href="#">October 2014</a></h6>
				<h6><a href="#">September 2014</a></h6>
				<h6><a href="#">August 2014</a></h6>
				<h6><a href="#">July 2014</a></h6>
			</div>
			<div class="categories">
				<h4>Categories</h4>
				<h6><a href="#">Vivamus vestibulum nulla</a></h6>
				<h6><a href="#">Integer vitae libero ac risus e</a></h6>
				<h6><a href="#">Vestibulum commo</a></h6>
				<h6><a href="#">Cras iaculis ultricies</a></h6>
			</div>

		</div>
	</div>
	<div class="clearfix"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\portal\resources\views/singlepage.blade.php ENDPATH**/ ?>