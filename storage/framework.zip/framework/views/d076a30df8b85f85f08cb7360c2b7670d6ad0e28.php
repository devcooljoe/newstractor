


<?php $__env->startSection('title'); ?>

<title>Global Breaking news updates | Latest news headlines | Public relations - News Tractor</title>
<link rel="canonical" href="<?php echo e(route('index')); ?>/" />
<meta name="keyword" content="" />
<meta name="description" content="Keep up with global news updates, trends, local news, fashion, sports, technologies, business, gist/gossips, entertainment, capus news, politics etc.. We are building the best global community and will want you to be part.">
<meta property="og:locale" content="en_EN" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Global Breaking news updates | Latest news headlines | Public relations - News Tractor" />
<meta property="og:description" content="Keep up with global news updates, trends, local news, fashion, sports, technologies, business, gist/gossips, entertainment, capus news, politics etc.. We are building the best global community and will want you to be part." />
<meta property="og:url" content="<?php echo e(route('index')); ?>" />
<meta property="og:site_name" content="NewsTractor" />
<meta property="og:image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="og:image:secure_url" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="og:image:width" content="800" />
<meta property="og:image:height" content="450" />
<meta property="og:image:alt" content="" />
<meta property="article:tag" content="about, news, headlines, NewsTractor" />
<meta property="article:section" content="" />
<meta property="article:published_time" content="" />
<meta property="article:modified_time" content="" />
<meta property="article:author" content="" />
<meta name="twitter:card" content="summary" />
<meta property="twitter:title" content="Global & Breaking news updates | Latest news headlines | Public relations - News Tractor" />
<meta property="twitter:description" content="Keep up with global news updates, trends, local news, fashion, sports, technologies, business, gist/gossips, entertainment, capus news, politics etc.. We are building the best global community and will want you to be part." />
<meta property="twitter:url" content="" />
<meta property="twitter:image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta property="twitter:image:width" content="800" />
<meta property="twitter:image:height" content="450" />
<meta property="twitter:image:alt" content="" />

<meta property="profile:username" content="" />
<link rel="image_src" href="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta itemprop="image" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />
<meta name="msapplication-TileImage" content="<?php echo e(route('index')); ?>/storage/assets/default/icon.png" />

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="main-content">
	<div class="col-md-9 total-news">
		<div class="slider">
			<script src="js/responsiveslides.min.js"></script>
			<script>
				// You can also use "$(window).load(function() {"
				$(function () {
					$("#conference-slider").responsiveSlides({
						auto: true,
						manualControls: '#slider3-pager',
					});
				});
			</script>
			<?php if($slide->count()>0): ?> 
			<div class="conference-slider">
				<!-- Slideshow 3 -->
				<ul class="conference-rslide" id="conference-slider">
					<?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
					<li><div class="pic-box" class="img-responsive"><img class="img-responsive" src="/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>"></div></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
				<!-- Slideshow 3 Pager -->
				<ul id="slider3-pager">
					<?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><a href="#"><div class="pic-box-small" class="img-responsive"><img class="img-responsive" src="/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>"></div></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
				<div class="breaking-news-title">
					<p>Lorem ipsum dolor sit amet, consectetur Nulla quis lorem neque, mattis venenatis lectus. </p>
				</div>
			</div>
			<h5 class="breaking">Breaking news</h5>
			<?php endif; ?>
			
		</div>
		<div class="posts">
			<div class="left-posts">
				<div class="world-news">
					<?php if($world->count()>0): ?>
					<div class="main-title-head">
						<h3>from around the world</h3>
						<a href="#">More +</a>
						<div class="clearfix"></div>
					</div>
					<div class="world-news-grids ">
						<?php $__currentLoopData = $world; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="world-news-grid img-responsive">
							<div class="img-cont-post img-responsive">
								<img src="/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" class="img-responsive"/>
							</div>
							<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" class="title"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
							<p><?php echo e(strlen($post->body)>95?substr($post->body, 0, 95).'...':$post->body); ?></p>
							<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="clearfix"></div>
					</div>
					<?php endif; ?>
				</div>
				<div class="latest-articles">
					<?php if($latest->count()>0): ?>
					<div class="main-title-head">
						<h3>latest articles</h3>
						<a href="#">More +</a>
						<div class="clearfix"></div>
					</div>
					<div class="world-news-grids">
						<?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="world-news-grid img-responsive">
							<div class="img-cont-post img-responsive">
								<img src="/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" class="img-responsive"/>
							</div>
							<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" class="title"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
							<p><?php echo e(strlen($post->body)>95?substr($post->body, 0, 95).'...':$post->body); ?></p>
							<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="clearfix"></div>
					</div>
					<?php endif; ?>
				</div>
				<div class="gallery">
					<div class="main-title-head">
						<h3>gallery</h3>
						<a href="#">More +</a>
						<div class="clearfix"></div>
					</div>
					<div class="gallery-images">
						<?php if($galtop->count()>0): ?>
						<div class="course_demo1">
							<ul id="flexiselDemo1">
								<?php $__currentLoopData = $galtop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">
										<div class="img-cont-post img-responsive" style="height:120px;">
										<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" />
										</div>
									</a>
								</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
						<?php endif; ?>
						<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
						<script type="text/javascript">
							$(window).load(function () {
								$("#flexiselDemo1").flexisel({
									visibleItems: 3,
									animationSpeed: 1000,
									autoPlay: true,
									autoPlaySpeed: 3000,
									pauseOnHover: true,
									enableResponsiveBreakpoints: true,
									responsiveBreakpoints: {
										portrait: {
											changePoint: 480,
											visibleItems: 2
										},
										landscape: {
											changePoint: 640,
											visibleItems: 2
										},
										tablet: {
											changePoint: 768,
											visibleItems: 3
										}
									}
								});

							});
						</script>
						<script type="text/javascript" src="js/jquery.flexisel.js"></script>
					</div>
					<?php if($galbottom->count()>0): ?>
					<div class="course_demo1">
						<ul id="flexiselDemo">
							<?php $__currentLoopData = $galbottom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">
										<div class="img-cont-post img-responsive" style="height:120px;">
										<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" />
										</div>
									</a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<?php endif; ?>
					<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
					<script type="text/javascript">
						$(window).load(function () {
							$("#flexiselDemo").flexisel({
								visibleItems: 3,
								animationSpeed: 1000,
								autoPlay: true,
								autoPlaySpeed: 3000,
								pauseOnHover: true,
								enableResponsiveBreakpoints: true,
								responsiveBreakpoints: {
									portrait: {
										changePoint: 480,
										visibleItems: 2
									},
									landscape: {
										changePoint: 640,
										visibleItems: 2
									},
									tablet: {
										changePoint: 768,
										visibleItems: 3
									}
								}
							});

						});
					</script>
					<script type="text/javascript" src="js/jquery.flexisel.js"></script>

				</div>
				<div class="tech-news">
					<?php if($leftmore->count()>0): ?>
					<div class="main-title-head">
						<h3>More To Read</h3>
						<a href="#">More +</a>
						<div class="clearfix"></div>
					</div>
					<?php endif; ?>
					<div class="tech-news-grids">
						<div class="left-tech-news">
							<?php $__currentLoopData = $leftmore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tech-news-grid span_66">
								<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
								<p><?php echo e(strlen($post->body)>100?substr($post->body, 0, 100).'...':$post->body); ?>

								</p>
								<p>by <a href="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>" style="text-transform: capitalize;"><?php echo e($post->user->name); ?></a> | <?php echo e($post->comment->count()); ?>

								<?php echo e($post->comment->count()>1?'Comments':'Comment'); ?></p>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="right-tech-news">
							<?php $__currentLoopData = $rightmore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tech-news-grid span_66">
								<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
								<p><?php echo e(strlen($post->body)>100?substr($post->body, 0, 100).'...':$post->body); ?>

								</p>
								<p>by <a href="<?php echo e(route('index')); ?>/profile/<?php echo e($post->user->username ?? $post->user->id); ?>" style="text-transform: capitalize;"><?php echo e($post->user->name); ?></a> | <?php echo e($post->comment->count()); ?>

								<?php echo e($post->comment->count()>1?'Comments':'Comment'); ?></p>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="right-posts">
				<?php if($desk->count()>0): ?>
				<div class="desk-grid">
					<h3>FROM THE desk</h3>
					<?php $__currentLoopData = $desk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="desk">
						<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" class="title">
							<?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?>

						</a>
						<p><?php echo e(strlen($post->body)>50?substr($post->body, 0, 50).'...':$post->body); ?></p>
						<p><a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a><span><?php echo e(((explode('-', $post->date))[0])); ?> <?php echo e(((explode('-', $post->date))[1])); ?>

							<?php echo e(((explode('-', $post->date))[2])); ?>, <?php echo e(((explode('-', $post->date))[3])); ?></span></p>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<a class="more" href="#">More +</a>
				</div>
				<?php endif; ?>
				<?php if($editorial->count()>0): ?>
				<div class="editorial">
					<h3>editorial</h3>
					<?php $__currentLoopData = $editorial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="editor">
						<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" class="img-cont-post">
							<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" />
						</a>
						<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>"><?php echo e(strlen($post->title)>80?substr($post->title, 0, 80).' ...':$post->title); ?></a>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="col-md-3 side-bar">
		<div class="videos">
			<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="video-grid">
				<div class="video" style="border: 2px solid white;overflow:hidden">
					<img src="<?php echo e(route('index')); ?>/storage/<?php echo e($post->file ?? ''); ?>" alt="<?php echo e($post->title); ?>" class="img-responsive">
				</div>
				<div class="video-name">
					<a href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">
						<?php echo e(substr($post->title, 0, 80)); ?>

						<?php echo e(strlen($post->title)>80?'...':''); ?>

					</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<a class="more1" href="#">More +</a>
			<div class="clearfix"></div>
		</div>
		<div class="sign_up text-center" id="subscribe">
			<h3>Sign Up for Newsletter</h3>
			<p class="sign">Sign up to receive our free newsletters!</p>
			<form>
				<input type="text" class="text" value="Name" onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'Name';}">
				<input type="text" class="text" value="Email Address" onfocus="this.value = '';"
					onblur="if (this.value == '') {this.value = 'Email Address';}">
				<input type="submit" value="submit">
			</form>
			<p class="spam">We do not spam. We value your privacy!</p>
		</div>
		<div class="clearfix"></div>
		<?php if($popular->count()>0): ?>
			<div class="popular mpopular">
				<div class="main-title-head">
					<h5>popular</h5>
					<h4> Most read</h4>
					<div class="clearfix"></div>
				</div>
				<div class="popular-news">
					<?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="popular-grid">
						<i>
							<?php echo e(((explode('-', $post->date))[0])); ?> <?php echo e(((explode('-', $post->date))[1])); ?>

							<?php echo e(((explode('-', $post->date))[2])); ?>, <?php echo e(((explode('-', $post->date))[3])); ?>

						</i>
						<p><?php echo e(substr($post->title, 0, 80)); ?>

							<?php echo e(strlen($post->title)>80?'...':''); ?>

							<a title="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>" href="<?php echo e(route('index')); ?>/<?php echo e($post->custom_id); ?>">Read More</a>
						</p>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>				
		<?php endif; ?>
		<div class="subscribe-now">
			<div class="discount">
				<a href="#subscribe">
					<div class="save">
						<p>Save</p>
						<p>upto</p>
					</div>
					<div class="percent">
						<h2>50%</h2>
					</div>
					<div class="clearfix"></div>
			</div>
			<h3 class="sn">subscribe now</h3>
			</a>
		</div>
		<div class="clearfix"></div>
	</div>
	<div class="clearfix"></div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\newstractor\resources\views/news/index.blade.php ENDPATH**/ ?>