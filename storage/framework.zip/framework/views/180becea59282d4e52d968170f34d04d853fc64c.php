


<?php $__env->startSection('title'); ?>

<title>The News Reporter a Magazine Category Flat Bootstarp Responsive Website Template| Home :: w3layouts</title>
<meta name="keywords" content="The keywords" />
<meta name="description" content="The description">
<!--webfont-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="main-content">
	<div class="col-md-9 total-news">
		<section class="slider">
			<div class="flexslider">
				<ul class="slides">
					<li>
						<a href="singlepage"><img src="images/s1.jpg" class="img-responsive" alt="" /></a>
					</li>
					<li>
						<a href="singlepage"><img src="images/s2.jpg" class="img-responsive" alt="" /></a>
					</li>
					<li>
						<a href="singlepage"><img src="images/s3.jpg" class="img-responsive" alt="" /></a>
					</li>
				</ul>
			</div>
		</section>
		<!-- FlexSlider -->
		<script defer src="js/jquery.flexslider.js"></script>
		<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
		<script type="text/javascript">
			$(function () {
				SyntaxHighlighter.all();
			});
			$(window).load(function () {
				$('.flexslider').flexslider({
					animation: "slide",
					start: function (slider) {
						$('body').removeClass('loading');
					}
				});
			});
		</script>
		<div class="sports-top">
			<div class="s-grid-left">
				<div class="cricket">
					<h3>CRICKET</h3>
					<div class="c-sports-main">
						<div class="c-image">
							<a href="singlepage"><img src="images/crt1.jpg" alt="" /></a>
						</div>
						<div class="c-text">
							<p>cricket</p>
							<a class="power" href="singlepage">Power Reigns Supreme at 11th Cricket World Cup</a>
							<a class="reu" href="singlepage">Reuters</a>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="s-grid-small">
						<div class="sc-image">
							<a href="singlepage"><img src="images/crt2.jpg" alt="" /></a>
						</div>
						<div class="sc-text">
							<p>cricket</p>
							<a class="power" href="singlepage">nternational Cricket Council President Walks out of
								World Cup Final After Trophy Snub</a>
							<a class="reu" href="singlepage">Press Trust Of India</a>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="s-grid-small">
						<div class="sc-image">
							<a href="singlepage"><img src="images/crt3.jpg" alt="" /></a>
						</div>
						<div class="sc-text">
							<p>cricket</p>
							<a class="power" href="singlepage">nternational Cricket Council President Walks out of
								World Cup Final After Trophy Snub</a>
							<a class="reu" href="singlepage">Press Trust Of India</a>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="s-grid-right">
				<div class="cricket">
					<h3>football</h3>
					<div class="c-sports-main">
						<div class="c-image">
							<a href="singlepage"><img src="images/fcrt1.jpg" alt="" /></a>
						</div>
						<div class="c-text">
							<p>football</p>
							<a class="power" href="singlepage">Power Reigns Supreme at 11th Cricket World Cup</a>
							<a class="reu" href="singlepage">Reuters</a>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="s-grid-small">
						<div class="sc-image">
							<a href="singlepage"><img src="images/fcrt2.jpg" alt="" /></a>
						</div>
						<div class="sc-text">
							<p>football</p>
							<a class="power" href="singlepage">nternational Cricket Council President Walks out of
								World Cup Final After Trophy Snub</a>
							<a class="reu" href="singlepage">Press Trust Of India</a>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="s-grid-small">
						<div class="sc-image">
							<a href="singlepage"><img src="images/fcrt3.jpg" alt="" /></a>
						</div>
						<div class="sc-text">
							<p>football</p>
							<a class="power" href="singlepage">nternational Cricket Council President Walks out of
								World Cup Final After Trophy Snub</a>
							<a class="reu" href="singlepage">Press Trust Of India</a>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="sports-top">
			<div class="s-grid-left">
				<div class="cricket">
					<h3>tennis</h3>
					<div class="c-sports-main">
						<div class="c-image">
							<a href="singlepage"><img src="images/tcrt1.jpg" alt="" /></a>
						</div>
						<div class="c-text">
							<p>tennis</p>
							<a class="power" href="singlepage">Power Reigns Supreme at 11th Cricket World Cup</a>
							<a class="reu" href="singlepage">Reuters</a>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="s-grid-small">
						<div class="sc-image">
							<a href="singlepage"><img src="images/tcrt2.jpg" alt="" /></a>
						</div>
						<div class="sc-text">
							<p>tennis</p>
							<a class="power" href="singlepage">nternational Cricket Council President Walks out of
								World Cup Final After Trophy Snub</a>
							<a class="reu" href="singlepage">Press Trust Of India</a>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="s-grid-small">
						<div class="sc-image">
							<a href="singlepage"><img src="images/tcrt3.jpg" alt="" /></a>
						</div>
						<div class="sc-text">
							<p>tennis</p>
							<a class="power" href="singlepage">nternational Cricket Council President Walks out of
								World Cup Final After Trophy Snub</a>
							<a class="reu" href="singlepage">Press Trust Of India</a>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="s-grid-right">
				<div class="cricket">
					<h3>formula1</h3>
					<div class="c-sports-main">
						<div class="c-image">
							<a href="singlepage"><img src="images/pcrt1.jpg" alt="" /></a>
						</div>
						<div class="c-text">
							<p>lorem</p>
							<a class="power" href="singlepage">Power Reigns Supreme at 11th Cricket World Cup</a>
							<a class="reu" href="singlepage">Reuters</a>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="s-grid-small">
						<div class="sc-image">
							<a href="singlepage"><img src="images/pcrt2.jpg" alt="" /></a>
						</div>
						<div class="sc-text">
							<p>lorem</p>
							<a class="power" href="singlepage">nternational Cricket Council President Walks out of
								World Cup Final After Trophy Snub</a>
							<a class="reu" href="singlepage">Press Trust Of India</a>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="s-grid-small">
						<div class="sc-image">
							<a href="singlepage"><img src="images/pcrt3.jpg" alt="" /></a>
						</div>
						<div class="sc-text">
							<p>lorem</p>
							<a class="power" href="singlepage">nternational Cricket Council President Walks out of
								World Cup Final After Trophy Snub</a>
							<a class="reu" href="singlepage">Press Trust Of India</a>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="photos">
			<h3>PHOTOS</h3>

			<div class="course_demo1">
				<ul id="flexiselDemo">
					<li>
						<a href="single"><img src="images/sg4.jpg" alt="" /></a>
					</li>
					<li>
						<a href="single"><img src="images/sg5.jpg" alt="" /></a>
					</li>
					<li>
						<a href="single"><img src="images/sg6.jpg" alt="" /></a>
					</li>
					<li>
						<a href="single"><img src="images/sg1.jpg" alt="" /></a>
					</li>
				</ul>
			</div>
			<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
			<script type="text/javascript">
				$(window).load(function () {
					$("#flexiselDemo").flexisel({
						visibleItems: 4,
						animationSpeed: 1000,
						autoPlay: true,
						autoPlaySpeed: 3000,
						pauseOnHover: true,
						enableResponsiveBreakpoints: true,
						responsiveBreakpoints: {
							portrait: {
								changePoint: 480,
								visibleItems: 2
							},
							landscape: {
								changePoint: 640,
								visibleItems: 2
							},
							tablet: {
								changePoint: 768,
								visibleItems: 3
							}
						}
					});

				});
			</script>
			<script type="text/javascript" src="js/jquery.flexisel.js"></script>
		</div>
	</div>
</div>
<div class="col-md-3 side-bar">
	<div class="videos">
		<div class="video-grid">
			<div class="video">
				<a href="single"><i class="play"></i></a>
			</div>
			<div class="video-name">
				<a href="single">Lorem ipsum dolor sit amet conse ctetur adipiscing elit</a>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="video-grid">
			<div class="video">
				<a href="single"><i class="play"></i></a>
			</div>
			<div class="video-name">
				<a href="single">Lorem ipsum dolor sit amet conse ctetur adipiscing elit</a>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="video-grid">
			<div class="video">
				<a href="single"><i class="play"></i></a>
			</div>
			<div class="video-name">
				<a href="single">Lorem ipsum dolor sit amet conse ctetur adipiscing elit</a>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="video-grid">
			<div class="video">
				<a href="single"><i class="play"></i></a>
			</div>
			<div class="video-name">
				<a href="single">Lorem ipsum dolor sit amet conse ctetur adipiscing elit</a>
			</div>
			<div class="clearfix"></div>
		</div>
		<a class="more1" href="single">More +</a>
		<div class="clearfix"></div>
	</div>
	<div class="sign_up text-center" id="subscribe">
		<h3>Sign Up for Newsletter</h3>
		<p class="sign">Sign up to receive our free newsletters!</p>
		<form>
			<input type="text" class="text" value="Name" onfocus="this.value = '';"
				onblur="if (this.value == '') {this.value = 'Name';}">
			<input type="text" class="text" value="Email Address" onfocus="this.value = '';"
				onblur="if (this.value == '') {this.value = 'Email Address';}">
			<input type="submit" value="submit">
		</form>
		<p class="spam">We do not spam. We value your privacy!</p>
	</div>
	<div class="clearfix"></div>
	<div class="popular">
		<div class="main-title-head">
			<h5>popular</h5>
			<h4> Most read</h4>
			<div class="clearfix"></div>
		</div>
		<div class="popular-news">
			<div class="popular-grid">
				<i>Sept 24th 2011 </i>
				<p>Lorem ipsum dolor sit amet conse ctetur adipiscing elit <a href="singlepage">Read More</a></p>
			</div>
			<div class="popular-grid">
				<i>Sept 24th 2011 </i>
				<p>Lorem ipsum dolor sit amet conse ctetur adipiscing elit <a href="singlepage">Read More</a></p>
			</div>
			<div class="popular-grid">
				<i>Sept 24th 2011 </i>
				<p>Lorem ipsum dolor sit amet conse ctetur adipiscing elit <a href="singlepage">Read More</a></p>
			</div>
			<div class="popular-grid">
				<i>Sept 24th 2011 </i>
				<p>Lorem ipsum dolor sit amet conse ctetur adipiscing elit <a href="singlepage">Read More</a></p>
			</div>
			<div class="popular-grid">
				<i>Sept 24th 2011 </i>
				<p>Lorem ipsum dolor sit amet conse ctetur adipiscing elit <a href="singlepage">Read More</a></p>
			</div>
			<a class="more" href="singlepage">More +</a>
		</div>
	</div>
	<div class="subscribe-now">
		<div class="discount">
			<a href="#subscribe">
				<div class="save">
					<p>Save</p>
					<p>upto</p>
				</div>
				<div class="percent">
					<h2>50%</h2>
				</div>
				<div class="clearfix"></div>
		</div>
		<h3 class="sn">subscribe now</h3>
		</a>
	</div>
	<div class="clearfix"></div>
</div>
<div class="clearfix"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\newstractor\resources\views/news/sports.blade.php ENDPATH**/ ?>