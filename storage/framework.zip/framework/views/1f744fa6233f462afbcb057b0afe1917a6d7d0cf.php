

<script>
    window.location.href = "404";
</script><?php /**PATH C:\project\newstractor\resources\views/auth/login.blade.php ENDPATH**/ ?>