<?php echo e($slot); ?>

<?php /**PATH C:\project\newstractor\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>