

<?php $__env->startSection('title'); ?>
<title>The News Reporter a Magazine Category Flat Bootstarp Responsive Website Template| Home :: w3layouts</title>
<meta name="keywords" content="The keywords" />
<meta name="description" content="The description">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="cont-margin">
    	<div class="jumbotron row jumbo1">
	        <div class="col col-lg-3 col-md-3 col-sm-3 col-xs-12 hidden-xs"><br></div>
	        <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-12">
				<h3>Add New Post</h3>
				<form action="/post/store" method="post" enctype="multipart/form-data" autocomplete="off">
				<?php echo csrf_field(); ?>
				<span class="ababout">Title</span>
				<input class="abform" type="text" value="<?php echo e(old('title')); ?>" name="title" maxlength="200">
				<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="has-error"><?php echo e($message); ?></span><br><br>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<br>
				<span class="ababout">Body</span>
				<textarea class="abform" name="body" cols="30" rows="10" maxlength="3000"><?php echo e(old('body')); ?></textarea>
				<?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  
				<span class="has-error"><?php echo e($message); ?></span><br><br>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>				
				<br>
				<span class="ababout">Category</span>
				<select name="category" id="" class="abform">
					<option value="">Select the Post Category</option>
					<option value="sports">Sports</option>
					<option value="tech">Tech</option>
					<option value="business">Business</option>
					<option value="gist">Gist/Gossip</option>
					<option value="entertainment">Entertainment</option>
					<option value="campus">Campusnews</option>
					<option value="politics">Politics</option>
					<option value="blogs">Blogs</option>
				</select>
				<?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="has-error"><?php echo e($message); ?></span><br><br>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<br>
				<br>
				<span class="ababout">Picture</span>
				<input class="btn" type="file" name="file" id="file" style="width:100%">
				<?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="has-error"><?php echo e($message); ?></span><br><br>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				<br>
				<br>
				<input type="submit" value="Post" class="sub-btn">
			</form>
	        </div>
	        <div class="col col-lg-3 col-md-3 col-sm-3 col-xs-12 hidden-xs"><br></div>
    	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\newstractor\resources\views/admin\post\new.blade.php ENDPATH**/ ?>